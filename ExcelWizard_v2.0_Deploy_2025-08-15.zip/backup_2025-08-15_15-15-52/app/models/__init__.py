# app/models/__init__.py
# Models package initialization
